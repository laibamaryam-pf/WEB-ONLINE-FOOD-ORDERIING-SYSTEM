<?php
session_start();
// Agar already logged in hai toh index pe jaye
if(isset($_SESSION['user_id'])){
    header("Location: ../pages/index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to FoodieHub</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="welcome-page">

<div class="welcome-container">
    <div class="welcome-logo">🍔</div>
    <h1>FoodieHub</h1>
    <p class="tagline">Your favourite food delivery partner</p>
    
    <div class="btn-group">
        <a href="register.php" class="btn-start">📝 REGISTER</a>
        <a href="login.php" class="btn-start" style="background: #1f2937;">🔐 LOGIN</a>
    </div>
    
    <div class="welcome-footer">
        <p>Delicious food delivered to your door 🍕🍔🥗</p>
    </div>
</div>

</body>
</html>