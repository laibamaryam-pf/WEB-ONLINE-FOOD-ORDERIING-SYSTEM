<?php
// Close the main div and body
?>
</div> <!-- Close .main -->
</body>
</html>