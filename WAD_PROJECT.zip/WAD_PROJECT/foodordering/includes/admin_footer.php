<?php
// admin_footer.php - Common footer for all admin pages
?>
</div> <!-- Close .main -->
</body>
</html>