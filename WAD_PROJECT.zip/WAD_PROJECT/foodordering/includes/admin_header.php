<?php
// admin_header.php - Common header for all admin pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Admin Panel'; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Admin CSS -->
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>🍔 FoodieHub</h2>
    <a href="../admin/dashboard.php">📊 Dashboard</a>
    <a href="../admin/foods.php">🍕 Manage Foods</a>
    <a href="../admin/add_food.php">➕ Add Food</a>
    <a href="../admin/order.php">📦 Orders</a>
    <a href="../auth/logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
    <!-- TOPBAR -->
    <div class="topbar">
        <h4><?php echo $page_heading ?? 'Dashboard'; ?></h4>
        <div>Welcome, <b><?php echo $_SESSION['name'] ?? 'Admin'; ?></b></div>
    </div>