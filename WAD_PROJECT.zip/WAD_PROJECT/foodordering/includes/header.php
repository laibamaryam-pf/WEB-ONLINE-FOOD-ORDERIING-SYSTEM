<?php
// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodieHub - Food Ordering System</title>
    
    <!-- Bootstrap CSS -->
   
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="index-page">

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>🍔 FoodieHub</h2>
    <a href="index.php">🏠 Home</a>
    <a href="cart.php">🛒 My Cart</a>
    <a href="about.php">👨‍🍳 Our Team</a>
    <a href="../auth/logout.php">🚪 Logout</a>
</div>

<!-- TOP NAVBAR -->
<div class="top-navbar">
    <div style="font-size: 20px; font-weight: bold;">
        🍔 FoodieHub - Food Ordering System
    </div>
    <div>
        <span class="welcome-text">Welcome, <?php echo $_SESSION['name']; ?>!</span>
        <a href="../auth/logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="main">