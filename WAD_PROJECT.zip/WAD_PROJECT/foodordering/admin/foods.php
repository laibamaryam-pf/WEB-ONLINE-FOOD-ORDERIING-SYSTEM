<?php
$page_title = "Manage Foods";
$page_heading = "Manage Foods";

include '../includes/admin_check.php';
include '../config/db.php';
include '../includes/admin_header.php';

$result = mysqli_query($conn, "SELECT * FROM food");
?>

<div class="food-table">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Food Items</h3>
        <a href="add_food.php" class="btn btn-success">➕ Add New Food</a>
    </div>
    
    <table class="table table-bordered table-hover align-middle">
        <thead>
            <tr>
                <th>ID</th>
                <th>Food Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = mysqli_fetch_assoc($result)){ ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo substr($row['description'], 0, 50); ?>...</td>
                <td>Rs. <?php echo $row['price']; ?></td>
                <td>
                    <img src="../assets/images/<?php echo $row['image']; ?>" class="food-img">
                </td>
                <td>
                    <a class="edit-btn" href="edit_food.php?id=<?php echo $row['id']; ?>">Edit</a>
                    <a class="delete-btn" href="delete_food.php?id=<?php echo $row['id']; ?>"
                       onclick="return confirm('⚠ Are you sure you want to delete this food?');">Delete</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>