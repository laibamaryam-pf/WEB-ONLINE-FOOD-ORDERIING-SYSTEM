<?php
$page_title = "Edit Food";
$page_heading = "Edit Food";

error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../includes/admin_check.php';
include '../config/db.php';
include '../includes/admin_header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($id == 0){
    echo "<div class='alert alert-danger'>Invalid ID</div>";
    echo "<a href='foods.php' class='btn btn-primary'>Back to Foods</a>";
    include '../includes/admin_footer.php';
    exit;
}

// fetch data
$result = $conn->query("SELECT * FROM food WHERE id=$id");

if(!$result || $result->num_rows == 0){
    echo "<div class='alert alert-danger'>Food not found!</div>";
    echo "<a href='foods.php' class='btn btn-primary'>Back to Foods</a>";
    include '../includes/admin_footer.php';
    exit;
}

$row = $result->fetch_assoc();

// update logic
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $oldImage = $row['image'];

    if(!empty($_FILES['image']['name'])){
        $image = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];

        $oldPath = "../assets/images/" . $oldImage;
        if(file_exists($oldPath)){
            unlink($oldPath);
        }

        move_uploaded_file($tmp, "../assets/images/" . $image);
    } else {
        $image = $oldImage;
    }

    $update = $conn->query("
        UPDATE food 
        SET name='$name',
        price='$price',
        description='$description',
        image='$image'
        WHERE id=$id
    ");

    if($update){
        echo "<script>alert('Food updated successfully!'); window.location.href='foods.php';</script>";
        exit;
    } else {
        echo "<div class='alert alert-danger'>Update failed: " . $conn->error . "</div>";
    }
}
?>

<div class="form-card">
    <h2>Edit Food</h2>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" class="form-control" value="<?php echo $row['name']; ?>" required>
        
        <input type="number" name="price" class="form-control" value="<?php echo $row['price']; ?>" required>

        <textarea name="description" class="form-control" rows="4" required><?php echo $row['description']; ?></textarea>

        <p><strong>Current Image:</strong></p>
        <img src="../assets/images/<?php echo $row['image']; ?>" width="100" class="food-img mb-3">

        <input type="file" name="image" class="form-control">

        <button type="submit" name="update" class="add-btn mt-3">✏️ Update Food</button>
    </form>
</div>

<?php include '../includes/admin_footer.php'; ?>