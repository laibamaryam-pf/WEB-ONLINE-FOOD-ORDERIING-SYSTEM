<?php
$page_title = "Admin Dashboard";
$page_heading = "Admin Dashboard";

include '../includes/admin_check.php';
include '../config/db.php';
include '../includes/admin_header.php';  // ✅ CSS + Sidebar + Topbar yahan se aayega

// 🔴 MANUALLY SET QUANTITY
if(isset($_POST['set_quantity'])){
    $food_id = $_POST['food_id'];
    $new_quantity = $_POST['new_quantity'];
    
    $update_query = "UPDATE food SET quantity = $new_quantity WHERE id = $food_id";
    
    if(mysqli_query($conn, $update_query)){
        echo "<script>alert('Quantity set to $new_quantity successfully!'); window.location.href='';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}

/* TOTAL COUNTS */
$totalFoods = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM food"))['total'];
$totalOrders = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM orders"))['total'];
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM users WHERE role='customer'"))['total'];
$soldOut = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM food WHERE quantity=0"))['total'];
?>

<!-- CARDS -->
<div class="cards">
    <div class="card-box blue">
        <h2><?php echo $totalFoods; ?></h2>
        <p>Total Foods</p>
    </div>
    <div class="card-box green">
        <h2><?php echo $totalOrders; ?></h2>
        <p>Total Orders</p>
    </div>
    <div class="card-box orange">
        <h2><?php echo $totalUsers; ?></h2>
        <p>Total Customers</p>
    </div>
    <div class="card-box red">
        <h2><?php echo $soldOut; ?></h2>
        <p>Sold Out Items</p>
    </div>
</div>

<!-- INVENTORY -->
<div class="inventory">
    <h3>Inventory Management</h3>

    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Food</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Set Quantity</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $foods = mysqli_query($conn,"SELECT * FROM food");
        while($row = mysqli_fetch_assoc($foods)){
        ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td>Rs. <?php echo $row['price']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td>
                <?php
                if($row['quantity'] == 0){
                    echo "<span class='badge-out'>Sold Out</span>";
                }
                elseif($row['quantity'] <= 5){
                    echo "<span class='badge-low'>Low Stock</span>";
                }
                else{
                    echo "<span class='badge-stock'>In Stock</span>";
                }
                ?>
            </div>
            <td>
                <form method="POST" style="display:flex; gap:5px;">
                    <input type="hidden" name="food_id" value="<?php echo $row['id']; ?>">
                    <input type="number" name="new_quantity" value="<?php echo $row['quantity']; ?>" 
                           class="quantity-input" min="0">
                    <button type="submit" name="set_quantity" class="set-btn">Set</button>
                </form>
            </div>
        </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>