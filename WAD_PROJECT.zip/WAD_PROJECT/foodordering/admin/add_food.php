<?php
$page_title = "Add Food";
$page_heading = "Add Food";

include '../includes/admin_check.php';
include '../config/db.php';
include '../includes/admin_header.php';
?>

<div class="form-card">
    <h2>Add New Food</h2>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" class="form-control" placeholder="Food Name" required>
        
        <input type="number" name="price" class="form-control" placeholder="Price" required>

        <select name="category_id" class="form-select" required>
            <option value="">Select Category</option>
            <?php
            $cats = $conn->query("SELECT * FROM categories");
            while($c = $cats->fetch_assoc()){
                echo "<option value='{$c['id']}'>{$c['name']}</option>";
            }
            ?>
        </select>

        <input type="file" name="image" class="form-control" required>

        <textarea name="description" class="form-control" placeholder="Food Description" rows="4" required></textarea>

        <button type="submit" name="add_food" class="add-btn">➕ Add Food</button>
    </form>
</div>

<?php
// Add food logic
if(isset($_POST['add_food'])){
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp, "../assets/images/" . $image);

    $sql = "INSERT INTO food (name, price, image, category_id, description)
            VALUES ('$name', '$price', '$image', '$category_id', '$description')";

    if($conn->query($sql)){
        echo "<script>alert('Food Added Successfully!'); window.location.href='foods.php';</script>";
    } else {
        die('Error: ' . $conn->error);
    }
}

include '../includes/admin_footer.php';
?>