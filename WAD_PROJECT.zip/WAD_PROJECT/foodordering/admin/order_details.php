<?php
$page_title = "Order Details";
$page_heading = "Order Details";

include '../includes/admin_check.php';
include '../config/db.php';
include '../includes/admin_header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($id == 0){
    echo "<div class='alert alert-danger'>Invalid Order ID</div>";
    echo "<a href='order.php' class='btn btn-primary'>Back to Orders</a>";
    include '../includes/admin_footer.php';
    exit;
}

// Get order info with payment method
$order_info = $conn->query("SELECT * FROM orders WHERE id = $id");
$order = $order_info->fetch_assoc();

$result = $conn->query("
SELECT 
    order_items.*,
    food.name,
    food.price AS food_price
FROM order_items
JOIN food ON order_items.food_id = food.id
WHERE order_items.order_id = $id
");

if(!$result){
    die("Query Error: " . $conn->error);
}
?>

<div class="order-box">
    <div style="background: #fff9f0; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
        <p><strong>Order ID:</strong> #<?php echo $id; ?></p>
        <p><strong>Payment Method:</strong> <span class="badge-stock"><?php echo ucfirst($order['payment_method']); ?></span></p>
        <p><strong>Delivery Address:</strong> <?php echo $order['address']; ?></p>
        <p><strong>Order Date:</strong> <?php echo $order['created_at']; ?></p>
    </div>

    <table class="table table-bordered table-hover align-middle">
        <thead>
            <tr>
                <th>Food</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grand_total = 0;
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $total = $row['food_price'] * $row['quantity'];
                    $grand_total += $total;
            ?>
            <tr>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td>Rs. <?php echo $row['food_price']; ?></td>
                <td>Rs. <?php echo $total; ?></td>
            </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>No items found in this order</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="total-box">
        Grand Total: Rs. <?php echo $grand_total; ?>
    </div>
    
    <div class="mt-3">
        <a href="order.php" class="back-btn">⬅ Back to Orders</a>
    </div>
</div>

<?php include '../includes/admin_footer.php'; ?>