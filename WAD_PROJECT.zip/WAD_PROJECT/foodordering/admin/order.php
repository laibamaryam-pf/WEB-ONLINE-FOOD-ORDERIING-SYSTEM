<?php
$page_title = "Manage Orders";
$page_heading = "Manage Orders";

include '../includes/admin_check.php';
include '../config/db.php';
include '../includes/admin_header.php';

$sql = "SELECT orders.*, users.name 
        FROM orders 
        JOIN users ON orders.user_id = users.id
        ORDER BY orders.id DESC";

$result = $conn->query($sql);

if(!$result){
    die("Query Error: " . $conn->error);
}
?>

<div class="orders-box">
    <table class="table table-bordered table-hover align-middle">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>User</th>
                <th>Total</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($result->num_rows == 0){ ?>
                <tr><td colspan="7" class="text-center">No Orders Found</td></tr>
            <?php } ?>

            <?php while($row = $result->fetch_assoc()){ ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td>Rs. <?php echo $row['total_price']; ?></td>
                <td><span class="badge-stock"><?php echo ucfirst($row['payment_method']); ?></span></td>
                <td>
                    <?php
                    if($row['status'] == 'pending'){
                        echo "<span class='pending'>Pending</span>";
                    }
                    elseif($row['status'] == 'processing'){
                        echo "<span class='processing'>Processing</span>";
                    }
                    else{
                        echo "<span class='delivered'>Delivered</span>";
                    }
                    ?>
                </td>
                <td><?php echo $row['created_at']; ?></td>
                <td>
                    <a class="view-btn" href="order_details.php?id=<?php echo $row['id']; ?>">View Details</a>
                    <br>
                    <a class="processing-btn" href="update_status.php?id=<?php echo $row['id']; ?>&status=processing">Processing</a>
                    <a class="delivered-btn" href="update_status.php?id=<?php echo $row['id']; ?>&status=delivered">Delivered</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include '../includes/admin_footer.php'; ?>