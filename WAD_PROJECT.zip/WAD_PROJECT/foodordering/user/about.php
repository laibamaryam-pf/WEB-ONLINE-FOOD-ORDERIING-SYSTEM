<?php
include '../includes/auth_check.php';
include '../config/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Team - Food App</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Main Style.css (Sidebar + Navbar) -->
<link rel="stylesheet" href="../assets/css/style.css">



</head>
<body class="index-page">

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>🍔 Food App</h2>
    <a href="index.php">🏠 Home</a>
    <a href="cart.php">🛒 My Cart</a>
    <a href="about.php">👨‍🍳 Our Team</a>
    <a href="../auth/logout.php">🚪 Logout</a>
</div>

<!-- TOP NAVBAR -->
<div class="top-navbar">
    <div style="font-size: 20px; font-weight: bold;">
        🍔 Food Ordering System
    </div>
    <div>
        <span class="welcome-text">Welcome, <?php echo $_SESSION['name']; ?>!</span>
        <a href="../auth/logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="main">
    <div class="container py-5">
        
        <!-- Hero Section -->
        <div class="about-hero">
            <h1>👨‍🍳 Our Creative Team</h1>
            <p>The passionate minds behind your food ordering experience</p>
        </div>

        <!-- Team Grid -->
        <div class="row justify-content-center g-4">
            
            <!-- Member 1 - Fatima -->
            <div class="col-md-6 col-lg-4">
                <div class="team-card">
                    <img src="../assets/images/member1.jpeg" class="team-img mx-auto">
                    <h4>Fatima Tahir</h4>
                    <p class="team-role">🎨 Frontend Developer</p>
                    <p class="team-bio">Creating beautiful and responsive interfaces that users love.</p>
                    <a href="fatima.php" class="btn-portfolio">View Portfolio →</a>
                </div>
            </div>

            <!-- Member 2 - Rehab -->
            <div class="col-md-6 col-lg-4">
                <div class="team-card">
                    <img src="../assets/images/member2.jpeg" class="team-img mx-auto">
                    <h4>Rehab Khalil</h4>
                    <p class="team-role">⚙️ Backend Developer</p>
                    <p class="team-bio">Building robust and scalable backend systems.</p>
                    <a href="rehab.php" class="btn-portfolio">View Portfolio →</a>
                </div>
            </div>

            <!-- Member 3 - Laiba -->
            <div class="col-md-6 col-lg-4">
                <div class="team-card">
                    <img src="../assets/images/Member 3.jpeg" class="team-img mx-auto">
                    <h4>Laiba Maryam</h4>
                    <p class="team-role">🗄️ Database Manager</p>
                    <p class="team-bio">Managing and optimizing database performance.</p>
                    <a href="laiba.php" class="btn-portfolio">View Portfolio →</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>