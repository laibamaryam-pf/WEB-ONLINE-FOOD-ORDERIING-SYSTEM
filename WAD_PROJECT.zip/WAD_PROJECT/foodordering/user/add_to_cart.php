<?php

session_start();

include '../includes/auth_check.php';
include '../config/db.php';

/* CHECK USER */
if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* CHECK FOOD ID */
if(!isset($_GET['id'])){
    die("Food ID missing");
}

$food_id = intval($_GET['id']);

/* GET FOOD */
$food = $conn->query("SELECT * FROM food WHERE id = $food_id");

if(!$food || $food->num_rows == 0){
    die("Food not found");
}

$rowFood = $food->fetch_assoc();

/* SOLD OUT CHECK */
if($rowFood['quantity'] <= 0){

    echo "<script>
    alert('Item is Sold Out');
    window.location.href='index.php';
    </script>";

    exit;
}

/* CHECK IF ITEM ALREADY IN CART */
$check = $conn->query("
SELECT * FROM cart 
WHERE user_id = $user_id 
AND food_id = $food_id
");

/* IF EXISTS → UPDATE */
if($check->num_rows > 0){

    $cartItem = $check->fetch_assoc();

    /* OPTIONAL STOCK LIMIT CHECK */
    if($cartItem['quantity'] < $rowFood['quantity']){

        $conn->query("
        UPDATE cart 
        SET quantity = quantity + 1 
        WHERE user_id = $user_id 
        AND food_id = $food_id
        ");

    }else{

        echo "<script>
        alert('Not enough stock available');
        window.location.href='cart.php';
        </script>";

        exit;
    }

}else{

    /* NEW ITEM INSERT */
    $conn->query("
    INSERT INTO cart(user_id, food_id, quantity)
    VALUES($user_id, $food_id, 1)
    ");

}

/* REDIRECT BACK TO MENU */
echo "<script>
alert('Item added to cart');
window.location.href='cart.php';
</script>";

exit;

?>