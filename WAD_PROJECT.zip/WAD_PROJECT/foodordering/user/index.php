<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../welcome.php");
    exit();
}
include '../includes/auth_check.php';
include '../config/db.php';
include '../includes/header.php';

/* LOAD CATEGORIES */
$catResult = $conn->query("SELECT * FROM categories");

/* GET SELECTED CATEGORY */
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : 1; 

/* LOAD FOOD BASED ON CATEGORY */
$stmt = $conn->prepare("SELECT * FROM food WHERE category_id = ?");

if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->bind_param("i", $category_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- CATEGORY FILTER BAR -->
<form method="GET">
    <select name="category_id" onchange="this.form.submit()">
        <?php while($cat = $catResult->fetch_assoc()){ ?>
            <option value="<?php echo $cat['id']; ?>"
                <?php if($cat['id'] == $category_id) echo 'selected'; ?>>
                <?php echo $cat['name']; ?>
            </option>
        <?php } ?>
    </select>
</form>

<h2>Our Menu</h2>

<div class="menu-container">
    <?php while($row = $result->fetch_assoc()){ ?>
        <div class="food-card">
            <img src="../assets/images/<?php echo $row['image']; ?>" 
                 alt="<?php echo $row['name']; ?>">
            <h3><?php echo $row['name']; ?></h3>
            <p class="price">Rs <?php echo $row['price']; ?></p>
            
            <!-- DESCRIPTION -->
            <div class="food-description">
                <?php echo $row['description']; ?>
            </div>
            
            <a href="add_to_cart.php?id=<?php echo $row['id']; ?>">
                Add to Cart
            </a>
        </div>
    <?php } ?>
</div>

<?php include '../includes/footer.php'; ?>