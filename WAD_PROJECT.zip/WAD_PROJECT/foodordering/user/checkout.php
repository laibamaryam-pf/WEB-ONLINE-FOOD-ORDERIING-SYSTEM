<?php
session_start();
date_default_timezone_set('Asia/Karachi');
include '../includes/auth_check.php';
include '../config/db.php';
include '../includes/header.php';

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];

// Get cart items
$cart = $conn->query("
SELECT cart.*, food.price, food.name as food_name, food.quantity as stock
FROM cart 
JOIN food ON cart.food_id = food.id 
WHERE cart.user_id = $user_id
");

$total = 0;
$items = [];

while($row = $cart->fetch_assoc()){
    $total += $row['price'] * $row['quantity'];
    $items[] = $row;
}

$receipt_data = null;

if(isset($_POST['place_order'])){
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $payment_method = 'cash_on_delivery';
    
    $conn->query("
        INSERT INTO orders (user_id, total_price, status, address, payment_method, created_at)
        VALUES ($user_id, $total, 'pending', '$address', '$payment_method', NOW())
    ");
    
    $order_id = $conn->insert_id;
    
    if($order_id > 0){
        foreach($items as $item){
            $food_id = (int)$item['food_id'];
            $qty = (int)$item['quantity'];
            $price = (float)$item['price'];
            
            $conn->query("INSERT INTO order_items (order_id, food_id, quantity, price) 
                         VALUES ($order_id, $food_id, $qty, $price)");
            
            $conn->query("UPDATE food SET quantity = quantity - $qty WHERE id = $food_id");
        }
        
        $conn->query("DELETE FROM cart WHERE user_id=$user_id");
        
      $receipt_data = [
    'order_id' => $order_id,
    'total' => $total,
    'address' => $address,
    'date' => date('d/m/Y h:i A'),  
    'items' => $items,
    'customer' => $user_name,
    'payment_method' => 'Cash on Delivery'
];
    }
}

if(empty($items) && !$receipt_data){
    echo "<script>alert('Your cart is empty!'); window.location='cart.php';</script>";
    exit();
}
?>

<div class="checkout-wrapper">
    <div class="cart-container">
        <h2>🛍️ Checkout</h2>
        
        <?php if(!$receipt_data): ?>
        
        <div class="checkout-summary">
            <h3>Order Summary</h3>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($items as $item){ 
                        $item_total = $item['price'] * $item['quantity'];
                    ?>
                    <tr>
                        <td><?php echo $item['food_name']; ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td>Rs <?php echo number_format($item['price'], 0); ?></td>
                        <td>Rs <?php echo number_format($item_total, 0); ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    <tr class="total-row">
                        <td colspan="3" style="text-align:right;"><strong>Grand Total:</strong></td>
                        <td><strong>Rs <?php echo number_format($total, 0); ?></strong></td>
                    </table>
                </tfoot>
            </table>
        </div>
        
        <div class="checkout-form">
            <form method="POST">
                <div class="form-group">
                    <label>👤 Customer Name</label>
                    <input type="text" value="<?php echo $user_name; ?>" disabled>
                </div>
                
                <div class="form-group">
                    <label>📍 Delivery Address</label>
                    <input type="text" name="address" placeholder="Enter your complete address" required>
                </div>
                
                <!-- Payment Method -->
                <div class="form-group">
                    <label>💵 Payment Method</label>
                    <div class="payment-box">
                        <input type="hidden" name="payment_method" value="cash_on_delivery">
                        <strong>💰 Cash on Delivery</strong>
                        <p>Pay when food arrives at your doorstep</p>
                    </div>
                </div>
                
                <div class="button-group">
                    <a href="cart.php" class="back-to-cart-btn">⬅ Back to Cart</a>
                    <button type="submit" name="place_order" class="checkout-btn">✅ Place Order</button>
                </div>
            </form>
        </div>
        
        <?php endif; ?>
    </div>
</div>

<!-- Receipt Modal -->
<?php if($receipt_data): ?>
<div id="receiptModal" class="receipt-modal">
    <div class="receipt-content">
        <span class="close-receipt" onclick="closeReceipt()">&times;</span>
        
        <div class="receipt-header">
            <div class="receipt-logo">🍔</div>
            <h3>Order Receipt</h3>
            <p>Thank you for your order!</p>
        </div>
        
        <div class="receipt-info">
            <p><strong>Order ID:</strong> #<?php echo $receipt_data['order_id']; ?></p>
            <p><strong>Customer:</strong> <?php echo $receipt_data['customer']; ?></p>
            <p><strong>Date:</strong> <?php echo $receipt_data['date']; ?></p>
             <p><strong>Time:</strong> <?php echo date('h:i A'); ?></p>  
            <p><strong>Address:</strong> <?php echo $receipt_data['address']; ?></p>
            <p><strong>Payment:</strong> <?php echo $receipt_data['payment_method']; ?></p>
        </div>
        
        <table class="receipt-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($receipt_data['items'] as $item): 
                    $item_total = $item['price'] * $item['quantity'];
                ?>
                <tr>
                    <td><?php echo $item['food_name']; ?></td>
                    <td style="text-align:center;"><?php echo $item['quantity']; ?></td>
                    <td style="text-align:right;">Rs <?php echo number_format($item['price'], 0); ?></td>
                    <td style="text-align:right;">Rs <?php echo number_format($item_total, 0); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="receipt-total-row">
                    <td colspan="3" style="text-align:right;"><strong>Grand Total:</strong></td>
                    <td style="text-align:right;"><strong>Rs <?php echo number_format($receipt_data['total'], 0); ?></strong></td>
                </tr>
            </tfoot>
        </table>
        
        <div class="receipt-actions">
            <button onclick="window.print()" class="print-btn">🖨️ Print</button>
            <a href="index.php" class="continue-shopping">🍔 Continue</a>
        </div>
    </div>
</div>
<script>
function closeReceipt() {
    document.getElementById('receiptModal').style.display = 'none';
    window.location.href = 'index.php';
}
</script>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>