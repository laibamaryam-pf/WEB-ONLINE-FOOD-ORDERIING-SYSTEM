
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Laiba Maryam | Blue · Lavender Dream</title>

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background: linear-gradient(135deg, #e0f2fe 0%, #f3e8ff 100%);
    color:#1e1b4b;
    overflow-x:hidden;
}

/* SCROLLBAR - blue lavender */
::-webkit-scrollbar{ width:8px; }
::-webkit-scrollbar-thumb{
    background: linear-gradient(135deg, #3b82f6, #a855f7);
    border-radius:20px;
}
::-webkit-scrollbar-track {
    background: #e0f2fe;
}

/* NAVBAR - light glass */
nav{
    width:100%;
    padding:16px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    top:0;
    z-index:1000;
    background: rgba(255, 255, 255, 0.94);
    backdrop-filter:blur(18px);
    box-shadow:0 2px 12px rgba(0, 0, 0, 0.03);
    border-bottom:1px solid rgba(59, 130, 246, 0.25);
}

.logo{
    font-size:28px;
    font-weight:700;
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    letter-spacing:-0.3px;
}

nav ul{
    display:flex;
    list-style:none;
    gap:30px;
}

nav ul li a{
    text-decoration:none;
    color:#4c1d95;
    font-weight:500;
    font-size:15px;
    transition:.3s;
    position: relative;
}

nav ul li a::after{
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0%;
    height: 2.5px;
    background: linear-gradient(95deg, #3b82f6, #a855f7);
    border-radius: 3px;
    transition: 0.3s;
}

nav ul li a:hover::after{
    width: 100%;
}

nav ul li a:hover{
    color:#3b82f6;
}

/* SOCIAL ICONS */
.social-icons{
    display:flex;
    gap:12px;
}

.social-icons a{
    width:38px;
    height:38px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    background: white;
    color:#3b82f6;
    font-size:16px;
    text-decoration:none;
    transition:.3s ease;
    box-shadow:0 2px 8px rgba(0,0,0,0.03);
    border:1px solid rgba(59, 130, 246, 0.25);
}

.social-icons a:hover{
    transform:translateY(-3px);
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    color:white;
    border-color:transparent;
}

/* HERO */
.hero{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    text-align:center;
    padding:130px 10% 100px;
    position:relative;
    overflow:hidden;
    background: radial-gradient(circle at 30% 25%, rgba(59, 130, 246, 0.06), rgba(240, 242, 255, 0.98));
}

/* SOFT GLOW ORBS */
.hero::before{
    content:'';
    position:absolute;
    width:420px;
    height:420px;
    background:#93c5fd;
    border-radius:50%;
    filter:blur(100px);
    opacity:0.3;
    top:-90px;
    left:-90px;
    animation:blueFloat 8s infinite alternate;
}

.hero::after{
    content:'';
    position:absolute;
    width:400px;
    height:400px;
    background:#c4b5fd;
    border-radius:50%;
    filter:blur(100px);
    opacity:0.28;
    right:-80px;
    bottom:-80px;
    animation:lavenderFloat 9s infinite alternate;
}

@keyframes blueFloat{
    0%{ transform:translateY(0px) scale(1);}
    100%{ transform:translateY(30px) scale(1.18);}
}

@keyframes lavenderFloat{
    0%{ transform:translateX(0px) scale(1);}
    100%{ transform:translateX(-30px) scale(1.2);}
}

.hero-content{
    position:relative;
    z-index:2;
    max-width:820px;
    animation:fadeUp 0.8s ease;
}

.hero-content h1{
    font-size:64px;
    line-height:1.2;
    margin-bottom:18px;
    font-weight:700;
    color:#1e1b4b;
}

.hero-content h1 span{
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.hero-content p{
    color:#5b21b6;
    font-size:17px;
    line-height:1.8;
    margin-bottom:38px;
}

/* BUTTONS - blue lavender */
.btns{
    display:flex;
    justify-content:center;
    gap:16px;
    flex-wrap:wrap;
}

.btn{
    padding:12px 32px;
    border:none;
    border-radius:50px;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
    text-decoration:none;
}

.btn-primary{
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    color:white;
    box-shadow:0 6px 16px rgba(59, 130, 246, 0.3);
}

.btn-primary:hover{
    transform:translateY(-3px);
    box-shadow:0 12px 24px rgba(59, 130, 246, 0.35);
}

.btn-outline{
    border:1.5px solid #3b82f6;
    background: rgba(255,255,255,0.8);
    color:#3b82f6;
}

.btn-outline:hover{
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    color:white;
    transform:translateY(-3px);
    border-color:transparent;
}

/* SECTIONS */
section{
    padding:80px 8%;
}

.section-title{
    text-align:center;
    margin-bottom:50px;
}

.section-title h2{
    font-size:42px;
    margin-bottom:10px;
    background:linear-gradient(135deg, #1e1b4b, #3b82f6);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    font-weight:700;
}

.section-title p{
    color:#5b21b6;
    font-size:15px;
}

/* GRIDS */
.services, .skills-grid, .projects{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

/* ===== COMMON BOX (SERVICES) - blue lavender ===== */
.box{
    background: rgba(255, 255, 255, 0.92);
    padding:35px 20px;
    text-align:center;
    border-radius:24px;
    box-shadow:0 8px 20px rgba(0, 0, 0, 0.03);
    transition:.4s;
    position:relative;
    overflow:hidden;
    color:#4c1d95;
    border:1px solid rgba(59, 130, 246, 0.25);
}

/* HOVER - BLUE LAVENDER GRADIENT */
.box:hover{
    transform:translateY(-12px) scale(1.05);
    background: linear-gradient(135deg, #3b82f6, #a855f7);
    color:white;
    box-shadow:0 25px 45px rgba(59, 130, 246, 0.3);
    border:1px solid rgba(59, 130, 246, 0.5);
}

/* ICON */
.box i{
    font-size:42px;
    margin-bottom:15px;
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    transition:.4s;
}

/* ICON HOVER */
.box:hover i{
    background: white;
    -webkit-background-clip:text;
    -webkit-text-fill-color:white;
    transform:scale(1.15);
}

/* TEXT */
.box h3{
    font-size:20px;
    font-weight:600;
    transition:.3s;
}

.box:hover h3{
    color:white;
}

/* LIGHT SWIPE EFFECT */
.box::before{
    content:"";
    position:absolute;
    width:100%;
    height:100%;
    top:0;
    left:-100%;
    background: linear-gradient(95deg, #3b82f6, #a855f7);
    transition:.5s;
    opacity:0.15;
    pointer-events:none;
}

.box:hover::before{
    left:100%;
}

/* SKILLS GRID */
.skills-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
    gap:22px;
}

/* SKILL CARD - DARK BEFORE HOVER */
.skill-card{
    background: #0f172a;
    padding:24px 16px;
    border-radius:28px;
    text-align:center;
    transition: all 0.35s ease;
    border:1px solid rgba(59, 130, 246, 0.3);
    cursor: pointer;
    box-shadow:0 10px 25px rgba(0, 0, 0, 0.15);
}

/* HOVER - BLUE LAVENDER GRADIENT */
.skill-card:hover{
    transform: translateY(-12px) scale(1.06);
    background: linear-gradient(135deg, #3b82f6, #a855f7);
    box-shadow:0 25px 45px rgba(59, 130, 246, 0.35);
    border:1px solid rgba(59, 130, 246, 0.6);
}

/* ICON */
.skill-icon{
    width:65px;
    height:65px;
    margin:auto;
    border-radius:22px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:32px;
    margin-bottom:16px;
    background: linear-gradient(135deg, #3b82f6, #a855f7);
    color:white;
    transition: all 0.3s ease;
}

/* ICON HOVER */
.skill-card:hover .skill-icon{
    transform: scale(1.2) rotate(5deg);
    background: white;
    color: #3b82f6;
}

/* TEXT - dark on default card */
.skill-card h3{
    margin-bottom:8px;
    font-size:18px;
    font-weight:600;
    transition:.3s;
    color: #e2e8f0;
}
.skill-card p{
    font-size:12px;
    transition:.3s;
    color: #94a3b8;
}

/* HOVER TEXT - turns white */
.skill-card:hover h3,
.skill-card:hover p{
    color:white;
}

/* PROJECT CARDS - blue lavender */
.project-card{
    background: rgba(255, 255, 255, 0.94);
    border-radius:24px;
    overflow:hidden;
    transition:.35s ease;
    border:1px solid rgba(59, 130, 246, 0.25);
    cursor:pointer;
}

.project-card img{
    width:100%;
    height:200px;
    object-fit:cover;
    transition:transform .5s ease;
}

.project-content{
    padding:22px;
}

/* HOVER EFFECT */
.project-card:hover{
    transform: translateY(-12px);
    box-shadow:0 25px 40px rgba(59, 130, 246, 0.2);
    background: white;
    border-color:rgba(59, 130, 246, 0.45);
}

/* IMAGE ZOOM */
.project-card:hover img{
    transform:scale(1.08);
    filter:brightness(97%);
}

/* TEXT HOVER GRADIENT */
.project-card h3{
    transition:0.3s;
    color:#1e1b4b;
    font-size:20px;
    margin-bottom:10px;
    font-weight:600;
}

.project-card:hover h3{
    background: linear-gradient(135deg, #3b82f6, #a855f7);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.project-card p{
    color:#5b21b6;
    font-size:14px;
    line-height:1.6;
}

/* SOFT OVERLAY EFFECT */
.project-card::after{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background: linear-gradient(to top, rgba(0,0,0,0.05), transparent);
    opacity:0;
    transition:0.4s;
    pointer-events:none;
    border-radius:24px;
}

.project-card:hover::after{
    opacity:1;
}

/* CONTACT - blue lavender */
.contact-box{
    background: rgba(255, 255, 255, 0.94);
    backdrop-filter:blur(10px);
    padding:50px;
    border-radius:40px;
    text-align:center;
    border:1px solid rgba(59, 130, 246, 0.25);
}

.contact-box h2{
    font-size:38px;
    margin-bottom:18px;
    background:linear-gradient(135deg, #1e1b4b, #3b82f6);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    font-weight:700;
}

.contact-box p{
    color:#5b21b6;
    line-height:1.9;
    font-size:15px;
    margin-bottom:30px;
}

.contact-social{
    display:flex;
    justify-content:center;
    gap:18px;
}

.contact-social a{
    width:46px;
    height:46px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    background: white;
    color:#3b82f6;
    font-size:20px;
    text-decoration:none;
    transition:.3s;
    border:1px solid #bfdbfe;
}

.contact-social a:hover{
    background:linear-gradient(135deg, #3b82f6, #a855f7);
    color:white;
    transform:translateY(-4px);
    border-color:transparent;
}

/* FOOTER */
footer{
    background: #1e1b4b;
    padding:28px;
    text-align:center;
    margin-top:50px;
    border-top:2px solid #3b82f6;
}

footer p{
    color:#c4b5fd;
    font-size:13px;
}

/* ANIMATION */
@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(30px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

/* RESPONSIVE */
@media(max-width:900px){
    nav ul{
        display:none;
    }
    .hero-content h1{
        font-size:48px;
    }
    .section-title h2{
        font-size:34px;
    }
    .contact-box{
        padding:35px 22px;
    }
}

@media(max-width:600px){
    .hero-content h1{
        font-size:36px;
    }
    .hero-content p{
        font-size:14px;
    }
    .btn{
        width:100%;
        text-align:center;
    }
    .contact-box{
        padding:28px 16px;
    }
}

::selection {
    background:#bfdbfe;
    color:#1e1b4b;
}

</style>
</head>

<body>

<!-- NAV -->
<nav>
    <div class="logo">Laiba Maryam</div>
    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#skills">Skills</a></li>
        <li><a href="#projects">Projects</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>
    <div class="social-icons">
        <a href="https://www.facebook.com/profile.php?id=100009901120602"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.instagram.com/laibamaryam678/"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com/in/laiba-maryam-5a4b74191/"><i class="fab fa-linkedin-in"></i></a>
    </div>
</nav>

<!-- HERO -->
<section class="hero" id="home">
    <div class="hero-content">
        <h1>Hello, I'm <span>Laiba Maryam</span></h1>
        <p>Creative Web Developer & CS Student building modern, responsive websites with clean code and elegant design.</p>
        <div class="btns">
            <a href="#projects" class="btn btn-primary">View Projects</a>
            <a href="../assets/cvs/Member 3.pdf" class="btn btn-outline" download>Download CV</a>
        </div>
    </div>
</section>

<!-- SERVICES -->
<section id="services">
    <div class="section-title">
        <h2>Services</h2>
        <p>What I can do for you</p>
    </div>
    <div class="services">
        <div class="box">
            <i class="fa-solid fa-code"></i>
            <h3>Web Development</h3></div>
        <div class="box">
            <i class="fa-solid fa-paintbrush"></i>
            <h3>UI Design</h3></div>
        <div class="box">
            <i class="fa-solid fa-database"></i>
            <h3>Database</h3></div>
        <div class="box">
            <i class="fa-solid fa-mobile-alt"></i>
            <h3>Responsive Design</h3></div>
        <div class="box">
            <i class="fa-solid fa-bug"></i>
            <h3>Bug Fixing</h3>
        </div>
    </div>
</section>

<!-- SKILLS - DARK BASE, BLUE LAVENDER ON HOVER -->
<section id="skills">
    <div class="section-title"><h2>Skills</h2><p>Technologies I work with</p></div>
    <div class="skills-grid">
        <div class="skill-card">
            <div class="skill-icon">
                <i class="fab fa-html5"></i></div><h3>HTML5</h3><p>Semantic & Structure</p></div>
        <div class="skill-card">
            <div class="skill-icon">
                <i class="fab fa-css3-alt"></i></div><h3>CSS3</h3><p>Flex/Grid, Animations</p></div>
        <div class="skill-card">
            <div class="skill-icon">
                <i class="fab fa-js"></i></div><h3>JavaScript</h3><p>Interactive Features</p></div>
        <div class="skill-card">

            <div class="skill-icon">
                <i class="fab fa-php"></i>
            </div>
            <h3>PHP</h3>
                <p>Backend Logic</p>
            </div>

        <div class="skill-card">
            <div class="skill-icon">
                <i class="fab fa-java"></i>
            </div>
            <h3>Java</h3
            ><p>OOP & GUI</p>
        </div>

        <div class="skill-card">
            <div class="skill-icon">
                <i class="fab fa-python"></i>
            </div>

            <h3>Python</h3><p>Scripting & Logic</p></div>
        <div class="skill-card">
            <div class="skill-icon">
                <i class="fab fa-github"></i>
            </div>

            <h3>GitHub</h3><p>Version Control</p></div>
        <div class="skill-card">
            <div class="skill-icon">
                <i class="fa-solid fa-paintbrush"></i>
            </div>
            
            <h3>Canva</h3><p>Graphic Design</p></div>
    </div>
</section>

<!-- PROJECTS -->
<section id="projects">
    <div class="section-title"><h2>My Projects</h2><p>Recent work & practice projects</p></div>

    <div class="projects">
        <div class="project-card">
            <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=1200&auto=format&fit=crop" alt="Food ordering">
            <div class="project-content"><h3>Food Ordering System</h3><p>Full-stack PHP + MySQL system with cart & admin panel.</p>
        </div>
        </div>

        <div class="project-card"
        ><img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop" alt="Hospital">
        <div class="project-content"><h3>Hospital Management</h3><p>Java & C++ OOP-based hospital system.</p>
    </div>

    </div>

        <div class="project-card">
            <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1200&auto=format&fit=crop" alt="Street light">
            <div class="project-content"><h3>Smart Street Light</h3><p>Arduino sensor-based automation project.</p></div>
        </div>

        <div class="project-card">
            <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200&auto=format&fit=crop" alt="Portfolio">
            <div class="project-content"><h3>Portfolio Website</h3><p>Modern responsive personal portfolio design.</p>
        </div>

    </div>

    </div>
</section>

<!-- CONTACT -->
<section id="contact">
    <div class="section-title"><h2>Contact</h2><p>Get in touch with me</p></div>
    <div class="contact-box">
        <h2>Let's Connect!</h2>
        <p>📧 laiba@example.com<br>📍 Pakistan<br>🎓 Computer Science Student</p>
        <div class="contact-social">
            <a href="https://www.facebook.com/profile.php?id=100009901120602"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.instagram.com/laibamaryam678/"><i class="fab fa-instagram"></i></a>
            <a href="https://www.linkedin.com/in/laiba-maryam-5a4b74191/"><i class="fab fa-linkedin-in"></i></a>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer>
    <p>© 2026 Laiba Maryam | All Rights Reserved</p>
</footer>

</body>
</html>