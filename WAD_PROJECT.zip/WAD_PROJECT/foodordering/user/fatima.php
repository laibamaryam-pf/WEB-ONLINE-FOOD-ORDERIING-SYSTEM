<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Fatima Tahir | Portfolio</title>

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<!-- FONT AWESOME -->
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background:#f8faff;
    color:#1e293b;
    overflow-x:hidden;
}

/* SCROLLBAR */

::-webkit-scrollbar{
    width:10px;
}

::-webkit-scrollbar-thumb{
    background:linear-gradient(#ff4d8d,#7c3aed);
    border-radius:20px;
}

/* NAVBAR */

nav{
    width:100%;
    padding:18px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    top:0;
    z-index:1000;
    background:rgba(255,255,255,.8);
    backdrop-filter:blur(15px);
    box-shadow:0 5px 20px rgba(0,0,0,.05);
}

.logo{
    font-size:32px;
    font-weight:800;
    background:linear-gradient(to right,#ff4d8d,#7c3aed,#06b6d4);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

nav ul{
    display:flex;
    list-style:none;
    gap:30px;
}

nav ul li a{
    text-decoration:none;
    color:#334155;
    font-weight:500;
    transition:.3s;
}

nav ul li a:hover{
    color:#ff4d8d;
}

/* SOCIAL ICONS */

.social-icons{
    display:flex;
    gap:15px;
}

.social-icons a{
    width:42px;
    height:42px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    background:white;
    color:#7c3aed;
    font-size:18px;
    text-decoration:none;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
    transition:.4s;
}

.social-icons a:hover{
    transform:translateY(-5px);
    background:linear-gradient(to right,#ff4d8d,#7c3aed);
    color:white;
}

/* HERO */

.hero{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    text-align:center;
    padding:140px 10% 100px;
    position:relative;
    overflow:hidden;
    background:linear-gradient(135deg,#fff1f7,#eef2ff,#ecfeff);
}

/* GLOW EFFECTS */

.hero::before{
    content:'';
    position:absolute;
    width:450px;
    height:450px;
    background:#ff4d8d;
    border-radius:50%;
    filter:blur(150px);
    opacity:.25;
    top:-100px;
    left:-100px;
    animation:float 6s infinite alternate;
}

.hero::after{
    content:'';
    position:absolute;
    width:400px;
    height:400px;
    background:#7c3aed;
    border-radius:50%;
    filter:blur(150px);
    opacity:.20;
    right:-100px;
    bottom:-100px;
    animation:float2 7s infinite alternate;
}

@keyframes float{
    from{transform:translateY(0px);}
    to{transform:translateY(40px);}
}

@keyframes float2{
    from{transform:translateX(0px);}
    to{transform:translateX(-40px);}
}

.hero-content{
    position:relative;
    z-index:2;
    max-width:900px;
    animation:fadeUp 1s ease;
}

.hero-content h1{
    font-size:75px;
    line-height:1.2;
    margin-bottom:20px;
    font-weight:800;
}

.hero-content h1 span{
    background:linear-gradient(to right,#ff4d8d,#7c3aed,#06b6d4);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.hero-content p{
    color:#475569;
    font-size:20px;
    line-height:1.9;
    margin-bottom:40px;
}

/* BUTTONS */

.btns{
    display:flex;
    justify-content:center;
    gap:20px;
    flex-wrap:wrap;
}

.btn{
    padding:15px 35px;
    border:none;
    border-radius:50px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.4s;
    text-decoration:none;
}

.btn-primary{
    background:linear-gradient(to right,#ff4d8d,#7c3aed);
    color:white;
    box-shadow:0 10px 30px rgba(124,58,237,.3);
}

.btn-primary:hover{
    transform:translateY(-5px);
}

.btn-outline{
    border:2px solid #7c3aed;
    background:white;
    color:#7c3aed;
}

.btn-outline:hover{
    background:#7c3aed;
    color:white;
}

/* STATS */

.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:25px;
    margin-top:70px;
}

.stat-box{
    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
    transition:.4s;
}

.stat-box:hover{
    transform:translateY(-10px);
}

.stat-box h2{
    font-size:42px;
    background:linear-gradient(to right,#ff4d8d,#7c3aed);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.stat-box p{
    color:#64748b;
}

/* SECTION */

section{
    padding:100px 8%;
}

.section-title{
    text-align:center;
    margin-bottom:60px;
}

.section-title h2{
    font-size:48px;
    margin-bottom:12px;
}

.section-title p{
    color:#64748b;
}

/* SERVICES */

.services{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:30px;
}

.service-box{
    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,.05);
    transition:.4s;
    border:2px solid transparent;
}

.service-box:hover{
    transform:translateY(-10px);
    border-color:#ff4d8d;
}

.service-box i{
    font-size:45px;
    background:linear-gradient(to right,#ff4d8d,#7c3aed);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.service-box h3{
    margin:20px 0 15px;
    font-size:24px;
}

.service-box p{
    color:#64748b;
    line-height:1.8;
}

/* SKILLS */

.skills-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
    gap:25px;
}

.skill-card{
    background:white;
    padding:30px 20px;
    border-radius:25px;
    text-align:center;
    box-shadow:0 10px 30px rgba(0,0,0,.05);
    transition:.4s;
}

.skill-card:hover{
    transform:translateY(-10px) scale(1.03);
    background:linear-gradient(135deg,#ff4d8d,#7c3aed,#06b6d4);
    color:white;
}

.skill-card:hover p{
    color:white;
}

.skill-icon{
    width:70px;
    height:70px;
    margin:auto;
    border-radius:20px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:32px;
    margin-bottom:18px;
    background:linear-gradient(to right,#ff4d8d,#7c3aed);
    color:white;
}

.skill-card h3{
    margin-bottom:8px;
    font-size:20px;
}

.skill-card p{
    color:#64748b;
    font-size:14px;
}

/* PROJECTS */

.projects{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
    gap:30px;
}

.project-card{
    background:white;
    border-radius:25px;
    overflow:hidden;
    box-shadow:0 10px 35px rgba(0,0,0,.05);
    transition:.4s;
}

.project-card:hover{
    transform:translateY(-10px);
}

.project-img img{
    width:100%;
    height:220px;
    object-fit:cover;
}

/* PROJECT CONTENT */

.project-content{
    padding:25px;
}

.project-content h3{
    margin-bottom:12px;
    font-size:24px;
}

.project-content p{
    color:#64748b;
    line-height:1.8;
}

/* CONTACT */

.contact-box{
    background:white;
    padding:60px;
    border-radius:30px;
    text-align:center;
    box-shadow:0 10px 35px rgba(0,0,0,.05);
}

.contact-box h2{
    font-size:45px;
    margin-bottom:20px;
}

.contact-box p{
    color:#64748b;
    line-height:2;
    font-size:17px;
    margin-bottom:30px;
}

.contact-social{
    display:flex;
    justify-content:center;
    gap:20px;
}

.contact-social a{
    width:50px;
    height:50px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#f3f4ff;
    color:#7c3aed;
    font-size:22px;
    text-decoration:none;
    transition:.4s;
}

.contact-social a:hover{
    background:linear-gradient(to right,#ff4d8d,#7c3aed);
    color:white;
    transform:translateY(-5px);
}

/* FOOTER */

footer{
    background:#111827;
    padding:30px;
    text-align:center;
    margin-top:70px;
}

footer p{
    color:#cbd5e1;
}

/* ANIMATION */

@keyframes fadeUp{

    from{
        opacity:0;
        transform:translateY(40px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

/* RESPONSIVE */

@media(max-width:900px){

    nav ul{
        display:none;
    }

    .hero-content h1{
        font-size:50px;
    }
}

@media(max-width:600px){

    .hero-content h1{
        font-size:38px;
    }

    .hero-content p{
        font-size:16px;
    }

    .btn{
        width:100%;
    }

    .contact-box{
        padding:35px 20px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->

<nav>

    <div class="logo">Fatima Tahir</div>

    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#skills">Skills</a></li>
        <li><a href="#projects">Projects</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>

    <div class="social-icons">

        <a href="https://www.instagram.com/fatim_atahir01/" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>

        <a href="https://www.linkedin.com/in/fatima-tahir-026634408/" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>

    </div>

</nav>

<!-- HERO -->

<section class="hero" id="home">

<div class="hero-content">

    <h1>Hello, I'm <span>Fatima Tahir</span></h1>

    <p>
        A passionate Computer Science student focused on
        web development, UI design, responsive websites,
        programming, and modern digital experiences.
    </p>

    <div class="btns">

        <a href="#projects" class="btn btn-primary">
            View Projects
        </a>

        <a href="../assets/cvs/Member 1.pdf" class="btn btn-outline" download>
    Download CV
</a>
    </div>

    <!-- STATS -->

    <div class="stats">

        <div class="stat-box">
            <h2>10+</h2>
            <p>Projects Completed</p>
        </div>

        <div class="stat-box">
            <h2>20+</h2>
            <p>Technical Skills</p>
        </div>

        <div class="stat-box">
            <h2>2026</h2>
            <p>Expected Graduation</p>
        </div>

    </div>

</div>

</section>

<!-- SERVICES -->

<section id="services">

<div class="section-title">
    <h2>My Services</h2>
    <p>Professional services I provide</p>
</div>

<div class="services">

    <div class="service-box">
        <i class="fa-solid fa-code"></i>
        <h3>Web Development</h3>
        <p>Responsive and modern websites using latest technologies.</p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-palette"></i>
        <h3>UI/UX Design</h3>
        <p>Beautiful interfaces with smooth layouts and animations.</p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-database"></i>
        <h3>Database Systems</h3>
        <p>MySQL database management and backend systems.</p>
    </div>

</div>

</section>

<!-- SKILLS -->

<section id="skills">

<div class="section-title">
    <h2>My Skills</h2>
    <p>Technologies & tools I know</p>
</div>

<div class="skills-grid">

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-html5"></i></div>
        <h3>HTML5</h3>
        <p>Modern Web Structure</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-css3-alt"></i></div>
        <h3>CSS3</h3>
        <p>Responsive Styling</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-js"></i></div>
        <h3>JavaScript</h3>
        <p>Interactive Websites</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-php"></i></div>
        <h3>PHP</h3>
        <p>Backend Development</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-database"></i></div>
        <h3>MySQL</h3>
        <p>Database Systems</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-java"></i></div>
        <h3>Java</h3>
        <p>OOP Programming</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-python"></i></div>
        <h3>Python</h3>
        <p>Programming Logic</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-file-word"></i></div>
        <h3>MS Word</h3>
        <p>Documentation</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-file-excel"></i></div>
        <h3>MS Excel</h3>
        <p>Data Handling</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-file-powerpoint"></i></div>
        <h3>PowerPoint</h3>
        <p>Presentations</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-paint-brush"></i></div>
        <h3>Canva</h3>
        <p>Graphic Designing</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-figma"></i></div>
        <h3>Figma</h3>
        <p>UI Designing</p>
    </div>

</div>

</section>

<!-- PROJECTS -->

<section id="projects">

<div class="section-title">
    <h2>My Projects</h2>
    <p>Recent projects & achievements</p>
</div>

<div class="projects">

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Food Ordering System</h3>

            <p>
                Full-stack food ordering website with login,
                admin panel, cart system, and database.
            </p>

        </div>

    </div>

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Hospital Management</h3>

            <p>
                Java and C++ based management system using
                object-oriented programming concepts.
            </p>

        </div>

    </div>

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Smart Street Light</h3>

            <p>
                Arduino automation project with sensors
                for smart street lighting system.
            </p>

        </div>

    </div>

    <!-- NEW PROJECT -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Portfolio Website</h3>

            <p>
                Personal responsive portfolio website with
                animations, modern UI, and smooth design.
            </p>

        </div>

    </div>

    <!-- NEW PROJECT -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Student Management System</h3>

            <p>
                Student record management project using PHP,
                MySQL, forms, and admin dashboard.
            </p>

        </div>

    </div>

</div>

</section>

<!-- CONTACT -->

<section id="contact">

<div class="contact-box">

    <h2>Contact Me</h2>

    <p>
        📧 fatima.tahir000786@gmail.com
        <br>
        📍 Rawalpindi, Pakistan
        <br>
        🎓 Computer Science Student
    </p>

    <div class="contact-social">

        <a href="https://www.instagram.com/fatim_atahir01/" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>

        <a href="https://www.linkedin.com/in/fatima-tahir-026634408/" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>

    </div>

</div>

</section>

<!-- FOOTER -->

<footer>

    <p>
        © 2026 Fatima Tahir | All Rights Reserved
    </p>

</footer>

</body>
</html>