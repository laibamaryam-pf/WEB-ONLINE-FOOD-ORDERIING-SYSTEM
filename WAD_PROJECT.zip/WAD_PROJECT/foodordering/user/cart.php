<?php
session_start();

include '../includes/auth_check.php';
include '../config/db.php';
include '../includes/header.php';

$user_id = $_SESSION['user_id'];

/* CART DATA */
$result = $conn->query("

SELECT 
cart.id as cart_id,
cart.quantity,
food.id as food_id,
food.name,
food.price,
food.image,
food.quantity as stock,
food.description

FROM cart

JOIN food 
ON cart.food_id = food.id

WHERE cart.user_id = $user_id

");

if(!$result){
    die("Query Error: " . $conn->error);
}
?>

<div class="cart-container">
    <h2>🛒 Your Cart</h2>

    <?php if($result->num_rows > 0) { ?>
    
    <table class="cart-table">
        <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Stock</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grand_total = 0;
            while($row = $result->fetch_assoc()){
                $total = $row['price'] * $row['quantity'];
                $grand_total += $total;
            ?>
                <tr>
                    <td>
                        <img src="../assets/images/<?php echo $row['image']; ?>" width="60" height="60" style="object-fit:cover; border-radius:10px;">
                    </td>
                    <td><?php echo $row['name']; ?></td>
                    <td class="cart-description"><?php echo isset($row['description']) ? substr($row['description'], 0, 40) : 'Delicious item'; ?></td>
                    <td>Rs. <?php echo number_format($row['price'], 0); ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td>Rs. <?php echo number_format($total, 0); ?></td>
                    <td>
                        <?php
                        if($row['stock'] <= 0){
                            echo "<span class='stock-out'>Out of Stock</span>";
                        }elseif($row['stock'] <= 5){
                            echo "<span class='stock-low'>Only {$row['stock']} left</span>";
                        }else{
                            echo "<span class='stock-good'>In Stock</span>";
                        }
                        ?>
                    </td>
                    <td>
                        <a class="remove-btn" href="remove_cart.php?id=<?php echo $row['cart_id']; ?>">
                            🗑 Remove
                        </a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="5" style="text-align:right; font-weight:bold;">Grand Total:</td>
                <td colspan="3" style="font-weight:bold; color:#e17055; font-size:20px;">Rs. <?php echo number_format($grand_total, 0); ?></td>
            </tr>
        </tfoot>
    </table>

    <div class="cart-actions">
        <a class="checkout-btn" href="checkout.php">
            🚀 Proceed to Checkout
        </a>
        <a class="continue-btn" href="index.php">
            🍔 Continue Shopping
        </a>
    </div>

    <?php } else { ?>
        <div class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <p>Your cart is empty!</p>
            <a href="index.php" class="order-now-btn">Order Now</a>
        </div>
    <?php } ?>
</div>

<?php include '../includes/footer.php'; ?>