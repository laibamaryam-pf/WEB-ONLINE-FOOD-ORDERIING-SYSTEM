<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Rehab Khalil | Portfolio</title>

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background: linear-gradient(135deg, #fdf2f8 0%, #fae8ff 25%, #f3e8ff 50%, #e9d5ff 75%, #fce7f3 100%);
    color:#3b0764;
    overflow-x:hidden;
}

/* SCROLLBAR - violet pink magic */

::-webkit-scrollbar{
    width:8px;
}

::-webkit-scrollbar-thumb{
    background: linear-gradient(135deg, #c084fc, #ec4899);
    border-radius:20px;
}

::-webkit-scrollbar-track {
    background: #fae8ff;
}

/* NAVBAR - light glass violet */

nav{
    width:100%;
    padding:20px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    top:0;
    z-index:1000;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter:blur(20px);
    box-shadow:0 2px 15px rgba(0, 0, 0, 0.03);
    border-bottom:1px solid rgba(192, 132, 252, 0.3);
}

.logo{
    font-size:32px;
    font-weight:800;
    background:linear-gradient(135deg, #a855f7, #ec4899, #c084fc);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    letter-spacing:-0.5px;
}

nav ul{
    display:flex;
    list-style:none;
    gap:38px;
}

nav ul li a{
    text-decoration:none;
    color:#6b21a5;
    font-weight:500;
    font-size:17px;
    transition:.3s;
    position: relative;
}

nav ul li a::after{
    content: '';
    position: absolute;
    bottom: -6px;
    left: 0;
    width: 0%;
    height: 3px;
    background: linear-gradient(95deg, #c084fc, #ec4899);
    border-radius: 3px;
    transition: 0.3s;
}

nav ul li a:hover::after{
    width: 100%;
}

nav ul li a:hover{
    color:#ec4899;
}

/* SOCIAL ICONS */

.social-icons{
    display:flex;
    gap:12px;
}

.social-icons a{
    width:42px;
    height:42px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    background: white;
    color:#c084fc;
    font-size:18px;
    text-decoration:none;
    transition:.3s ease;
    box-shadow:0 2px 8px rgba(0,0,0,0.03);
    border:1px solid rgba(192, 132, 252, 0.25);
}

.social-icons a:hover{
    transform:translateY(-4px);
    background:linear-gradient(135deg, #c084fc, #ec4899);
    color:white;
    border-color:transparent;
}

/* HERO - dreamy violet pink */

.hero{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    text-align:center;
    padding:150px 10% 100px;
    position:relative;
    overflow:hidden;
    background: radial-gradient(circle at 30% 25%, rgba(192, 132, 252, 0.08), rgba(253, 242, 248, 0.96));
}

/* VIOLET PINK GLOW ORBS */

.hero::before{
    content:'';
    position:absolute;
    width:500px;
    height:500px;
    background:#d8b4fe;
    border-radius:50%;
    filter:blur(120px);
    opacity:0.35;
    top:-100px;
    left:-100px;
    animation:violetFloat 8s infinite alternate;
}

.hero::after{
    content:'';
    position:absolute;
    width:480px;
    height:480px;
    background:#f9a8d4;
    border-radius:50%;
    filter:blur(120px);
    opacity:0.35;
    right:-90px;
    bottom:-90px;
    animation:pinkFloat 9s infinite alternate;
}

@keyframes violetFloat{
    0%{ transform:translateY(0px) scale(1);}
    100%{ transform:translateY(35px) scale(1.18);}
}

@keyframes pinkFloat{
    0%{ transform:translateX(0px) scale(1);}
    100%{ transform:translateX(-35px) scale(1.2);}
}

.hero-content{
    position:relative;
    z-index:2;
    max-width:900px;
    animation:fadeUp 0.8s ease;
}

.hero-content h1{
    font-size:70px;
    line-height:1.2;
    margin-bottom:22px;
    font-weight:800;
    color:#2e1065;
}

.hero-content h1 span{
    background:linear-gradient(135deg, #a855f7, #ec4899, #c084fc);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.hero-content p{
    color:#7e5a9b;
    font-size:19px;
    line-height:1.9;
    margin-bottom:42px;
    max-width:750px;
    margin-left:auto;
    margin-right:auto;
}

/* BUTTONS - violet pink */

.btns{
    display:flex;
    justify-content:center;
    gap:20px;
    flex-wrap:wrap;
}

.btn{
    padding:14px 38px;
    border:none;
    border-radius:60px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
    text-decoration:none;
}

.btn-primary{
    background:linear-gradient(135deg, #a855f7, #ec4899);
    color:white;
    box-shadow:0 8px 20px rgba(168, 85, 247, 0.3);
}

.btn-primary:hover{
    transform:translateY(-4px);
    box-shadow:0 14px 28px rgba(236, 72, 153, 0.35);
}

.btn-outline{
    border:2px solid #c084fc;
    background: rgba(255,255,255,0.8);
    color:#a855f7;
    font-weight:600;
}

.btn-outline:hover{
    background:linear-gradient(135deg, #c084fc, #ec4899);
    color:white;
    transform:translateY(-4px);
    border-color:transparent;
}

/* STATS - light violet cards */

.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(210px,1fr));
    gap:28px;
    margin-top:75px;
}

.stat-box{
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter:blur(8px);
    padding:35px 25px;
    border-radius:32px;
    transition:.3s ease;
    border:1px solid rgba(192, 132, 252, 0.3);
}

.stat-box:hover{
    transform:translateY(-8px);
    background: white;
    border-color:#d8b4fe;
    box-shadow:0 15px 30px rgba(192, 132, 252, 0.12);
}

.stat-box h2{
    font-size:46px;
    background:linear-gradient(135deg, #a855f7, #ec4899);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    font-weight:800;
}

.stat-box p{
    color:#7e5a9b;
    font-weight:500;
    margin-top:8px;
    font-size:16px;
}

/* SECTION */

section{
    padding:90px 8%;
}

.section-title{
    text-align:center;
    margin-bottom:55px;
}

.section-title h2{
    font-size:48px;
    margin-bottom:12px;
    background:linear-gradient(135deg, #a855f7, #ec4899);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    font-weight:800;
    letter-spacing:-0.5px;
}

.section-title p{
    color:#8b6cb0;
    font-size:17px;
}

/* SERVICES - violet pink glass */

.services{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(290px,1fr));
    gap:30px;
}

.service-box{
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter:blur(8px);
    padding:38px;
    border-radius:32px;
    transition:.4s ease;
    border:1px solid rgba(192, 132, 252, 0.25);
}

.service-box:hover{
    transform:translateY(-10px);
    border-color:#d8b4fe;
    background: white;
    box-shadow:0 20px 35px rgba(168, 85, 247, 0.1);
}

.service-box i{
    font-size:54px;
    background:linear-gradient(135deg, #c084fc, #ec4899);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.service-box h3{
    margin:22px 0 14px;
    font-size:25px;
    color:#4c1d95;
}

.service-box p{
    color:#7e5a9b;
    line-height:1.8;
    font-size:15px;
}

/* SKILLS - vibrant gradient on hover */

.skills-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(175px,1fr));
    gap:25px;
}

.skill-card{
    background: rgba(255, 255, 255, 0.92);
    padding:28px 18px;
    border-radius:32px;
    text-align:center;
    transition: all 0.4s cubic-bezier(0.2, 0.9, 0.4, 1.1);
    border:1px solid rgba(192, 132, 252, 0.3);
    cursor: pointer;
}

/* GRADIENT EFFECT ON HOVER - Cyan to Purple to Green */
.skill-card:hover{
    transform: translateY(-14px) scale(1.06);
    background: linear-gradient(135deg, #ffffff, #f5f0ff);
    border-color: #bc3292;
    box-shadow: 0 25px 40px rgba(129, 5, 102, 0.25), 0 0 0 2px rgba(185, 126, 241, 0.1);
}

.skill-card:hover .skill-icon{
    background: linear-gradient(to right, #f086d4, #a855f7, #43385b);
    color: white;
    transform: scale(1.12) rotate(3deg);
    box-shadow: 0 0 20px #aa7da5;
}

.skill-card:hover h3{
    background: linear-gradient(to right, #f086d4, #a855f7, #43385b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    transform: scale(1.02);
}

.skill-card:hover p{
    background: linear-gradient(to right, #f086d4, #a855f7, #43385b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 600;
}

.skill-icon{
    width:70px;
    height:70px;
    margin:auto;
    border-radius:25px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:34px;
    margin-bottom:18px;
    background: #faf5ff;
    color: #a855f7;
    transition: all 0.35s ease;
    border:1px solid #e9d5ff;
}

.skill-card h3{
    margin-bottom:10px;
    font-size:20px;
    font-weight:700;
    color:#4c1d95;
    transition: all 0.3s;
}

.skill-card p{
    color:#8b6cb0;
    font-size:13px;
    transition: all 0.3s;
}

/* PROJECTS - violet pink cards */

.projects{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(330px,1fr));
    gap:32px;
}

.project-card{
    background: rgba(255, 255, 255, 0.92);
    border-radius:32px;
    overflow:hidden;
    transition:.4s ease;
    border:1px solid rgba(192, 132, 252, 0.25);
}

.project-card:hover{
    transform:translateY(-10px);
    border-color:#d8b4fe;
    background: white;
    box-shadow:0 20px 40px rgba(168, 85, 247, 0.12);
}

.project-img{
    overflow:hidden;
}

.project-img img{
    width:100%;
    height:230px;
    object-fit:cover;
    transition:transform .55s ease;
}

.project-card:hover img{
    transform:scale(1.06);
}

.project-content{
    padding:26px;
}

.project-content h3{
    margin-bottom:12px;
    font-size:23px;
    color:#4c1d95;
    font-weight:700;
}

.project-content p{
    color:#7e5a9b;
    line-height:1.7;
    font-size:15px;
}

/* CONTACT - violet pink elegant */

.contact-box{
    background: rgba(255, 255, 255, 0.94);
    backdrop-filter:blur(14px);
    padding:55px;
    border-radius:55px;
    text-align:center;
    border:1px solid rgba(192, 132, 252, 0.35);
}

.contact-box h2{
    font-size:48px;
    margin-bottom:22px;
    background:linear-gradient(135deg, #a855f7, #ec4899);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    font-weight:800;
}

.contact-box p{
    color:#7e5a9b;
    line-height:2;
    font-size:17px;
    margin-bottom:35px;
}

.contact-social{
    display:flex;
    justify-content:center;
    gap:22px;
}

.contact-social a{
    width:52px;
    height:52px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    background: white;
    color:#c084fc;
    font-size:24px;
    text-decoration:none;
    transition:.3s;
    border:1px solid #e9d5ff;
}

.contact-social a:hover{
    background:linear-gradient(135deg, #c084fc, #ec4899);
    color:white;
    transform:translateY(-6px);
    border-color:transparent;
}

/* FOOTER - deep violet */

footer{
    background: #2e1065;
    padding:32px;
    text-align:center;
    margin-top:70px;
    border-top:2px solid #ec4899;
}

footer p{
    color:#d8b4fe;
    font-size:15px;
    font-weight:500;
}

/* ANIMATION */

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(35px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

/* RESPONSIVE */

@media(max-width:900px){
    nav ul{
        display:none;
    }
    .hero-content h1{
        font-size:55px;
    }
    .section-title h2{
        font-size:40px;
    }
    .contact-box{
        padding:45px 25px;
    }
}

@media(max-width:600px){
    .hero-content h1{
        font-size:42px;
    }
    .hero-content p{
        font-size:16px;
    }
    .btn{
        width:100%;
        text-align:center;
    }
    .contact-box{
        padding:35px 20px;
    }
    .stat-box{
        padding:25px;
    }
}

::selection {
    background:#f3e8ff;
    color:#4c1d95;
}

.skill-card:active {
    transform: scale(0.98);
    transition: 0.05s;
}

</style>
</head>

<body>

<!-- NAVBAR -->

<nav>

    <div class="logo">Rehab Khalil</div>

    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#skills">Skills</a></li>
        <li><a href="#projects">Projects</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>

    <div class="social-icons">

        <a href="https://www.instagram.com/rehabkhalil_/" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>

        <a href="https://www.linkedin.com/in/rehab-khalil-5397763a9/" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>

        <a href="https://www.facebook.com/rehabb.khalil" target="_blank">
    <i class="fab fa-facebook-f"></i>
</a>

    </div>

</nav>

<!-- HERO -->

<section class="hero" id="home">

<div class="hero-content">

    <h1>Hello, I'm <span>Rehab Khalil</span></h1>

<p>
    Turning ideas into interactive digital experiences through
    clean code, creative design, and modern web technologies.
    Passionate about crafting responsive websites that combine
    innovation, functionality, and elegant user experiences.
</p>


    <div class="btns">

        <a href="#projects" class="btn btn-primary">
            View Projects
        </a>
<a href="../assets/cvs/member2.pdf" class="btn btn-outline" download>
    Download CV
</a>

    </div>

    <!-- STATS -->

    <div class="stats">

        <div class="stat-box">
            <h2>10+</h2>
            <p>Projects Completed</p>
        </div>

        <div class="stat-box">
            <h2>15+</h2>
            <p>Technical Skills</p>
        </div>

        <div class="stat-box">
            <h2>2028</h2>
            <p>Expected Graduation</p>
        </div>

    </div>

</div>

</section>

<!-- SERVICES -->

<section id="services">

<div class="section-title">
    <h2>What I Do</h2>
    <p>Creative and technical solutions I love building</p>
</div>

<div class="services">

    <div class="service-box">
        <i class="fa-solid fa-laptop-code"></i>
        <h3>Frontend Development</h3>
        <p>
            Designing responsive and interactive websites
            with modern layouts, animations, and clean UI.
        </p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-code"></i>
        <h3>Backend Development</h3>
        <p>
            Building dynamic systems using PHP, Java,
            MySQL, and structured backend logic.
        </p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-mobile-screen-button"></i>
        <h3>Responsive Design</h3>
        <p>
            Creating websites that work smoothly on
            desktops, tablets, and mobile devices.
        </p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-palette"></i>
        <h3>UI/UX Designing</h3>
        <p>
            Crafting modern user interfaces with
            visually appealing and user-friendly designs.
        </p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-database"></i>
        <h3>Database Management</h3>
        <p>
            Managing and organizing databases efficiently
            using MySQL and relational systems.
        </p>
    </div>

    <div class="service-box">
        <i class="fa-solid fa-diagram-project"></i>
        <h3>Software Projects</h3>
        <p>
            Developing academic and personal software
            projects with problem-solving approaches.
        </p>
    </div>

</div>

</section>

<!-- SKILLS -->

<section id="skills">

<div class="section-title">
    <h2>Technical Skills</h2>
    <p>Technologies, tools, and concepts I work with</p>
</div>

<div class="skills-grid">

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-code"></i></div>
        <h3>C++</h3>
        <p>Problem Solving & Logic Building</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-java"></i></div>
        <h3>Java</h3>
        <p>Object-Oriented Programming</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-html5"></i></div>
        <h3>HTML5</h3>
        <p>Modern Web Structure</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-css3-alt"></i></div>
        <h3>CSS3</h3>
        <p>Responsive Web Styling</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-js"></i></div>
        <h3>JavaScript</h3>
        <p>Interactive Web Features</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-php"></i></div>
        <h3>PHP</h3>
        <p>Backend Web Development</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-database"></i></div>
        <h3>SQL / MySQL</h3>
        <p>Database Design & Queries</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-sitemap"></i></div>
        <h3>DSA</h3>
        <p>Data Structures & Algorithms</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-cubes"></i></div>
        <h3>OOP</h3>
        <p>Classes, Objects & Concepts</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fab fa-figma"></i></div>
        <h3>Figma</h3>
        <p>UI/UX Prototyping</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-paint-brush"></i></div>
        <h3>Canva</h3>
        <p>Creative Graphic Designing</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-file-word"></i></div>
        <h3>MS Word</h3>
        <p>Professional Documentation</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-file-excel"></i></div>
        <h3>MS Excel</h3>
        <p>Spreadsheets & Data Handling</p>
    </div>

    <div class="skill-card">
        <div class="skill-icon"><i class="fas fa-file-powerpoint"></i></div>
        <h3>MS PowerPoint</h3>
        <p>Presentations & Slides</p>
    </div>

</div>

</section>

<!-- PROJECTS -->

<section id="projects">

<div class="section-title">
    <h2>My Projects</h2>
    <p>Academic and development projects I have worked on</p>
</div>

<div class="projects">

    <!-- PROJECT 1 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Hospital Management System (C++)</h3>

            <p>
                Hospital management software developed in C++
                using object-oriented programming concepts,
                patient records, and appointment handling.
            </p>

        </div>

    </div>

    <!-- PROJECT 2 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Hospital Management System (Java)</h3>

            <p>
                Java-based hospital management application
                with GUI, billing system, and appointment
                management features.
            </p>

        </div>

    </div>

    <!-- PROJECT 3 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Online Food Ordering System (Java)</h3>

            <p>
                Food ordering application developed in Java
                with menu handling, order processing,
                and customer management system.
            </p>

        </div>

    </div>

    <!-- PROJECT 4 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Automatic Street Light System</h3>

            <p>
                Arduino and DLD-based smart street light
                project using sensors, LEDs, resistors,
                wires, and automation concepts.
            </p>

        </div>

    </div>

    <!-- PROJECT 5 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1556740749-887f6717d7e4?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>ATM Management System Using DSA</h3>

            <p>
                ATM simulation system in C++ using data
                structures and algorithms for account
                handling, transactions, and security.
            </p>

        </div>

    </div>

    <!-- PROJECT 6 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1544383835-bda2bc66a55d?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>MySQL Food Ordering Database</h3>

            <p>
                Database management project for food ordering
                system using MySQL tables, queries,
                relationships, and admin operations.
            </p>

        </div>

    </div>

    <!-- PROJECT 7 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Web Online Food Ordering System</h3>

            <p>
                Full-stack responsive food ordering website
                with login/signup, cart system, admin panel,
                and PHP + MySQL integration.
            </p>

        </div>

    </div>

    <!-- PROJECT 8 -->

    <div class="project-card">

        <div class="project-img">
            <img src="https://images.unsplash.com/photo-1516321497487-e288fb19713f?q=80&w=1200&auto=format&fit=crop" alt="">
        </div>

        <div class="project-content">

            <h3>Digital Voting System</h3>

            <p>
                Proteus-based electronic voting system
                designed using digital logic concepts,
                switches, counters, and display modules.
            </p>

        </div>

    </div>

</div>

</section>

<section id="contact">

<div class="contact-box">

    <h2>Contact Me</h2>

    <p>
        📧 rehabkhalil.005@gmail.com
        <br>
        📍 Rawalpindi, Pakistan
        <br>
        🎓 Computer Science Student
    </p>

    <div class="contact-social">

        <a href="https://instagram.com/" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>

        <a href="https://www.linkedin.com/in/rehab-khalil-5397763a9/" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>
  <a href="https://www.facebook.com/rehabb.khalil" target="_blank">
    <i class="fab fa-facebook-f"></i>
</a>

    </div>

</div>

</section>

<!-- FOOTER -->

<footer>

    <p>
        © 2026 Rehab Khalil | All Rights Reserved
    </p>

</footer>

</body>
</html>
